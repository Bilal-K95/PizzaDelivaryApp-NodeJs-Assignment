import React from 'react'
import { Form, Button } from 'react-bootstrap'
import { useNavigate, useLocation } from 'react-router-dom'

export default function Checkout() {
    const navigate = useNavigate()
    const location = useLocation()
    return (
        <React.Fragment>
            <h3 className="my-2">Checkout</h3>
            <Form.Group controlId="formcreditcard">
                <Form.Label>Credit Card</Form.Label>
                <Form.Control type="number" />
            </Form.Group>
            <p>Order Total: <span style={{ fontWeight: 'bold' }}>$ {location.state}</span></p>
            <p><Button variant="dark" onClick={() => navigate("/order")}>Checkout</Button></p>
        </React.Fragment>
    )
}
