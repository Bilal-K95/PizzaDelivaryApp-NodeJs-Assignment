import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import LoginNav from "./LoginNav";
import axios from "axios";
import { useNavigate } from "react-router";

const Loginform = () => {
  const [state, setState] = useState({ email: "", password: "" });
  let navigate=useNavigate();
  let data;

  const handleOnChange = (e) => {
    const { name, value } = e.target;
    setState({ ...state, [name]: value });
    console.log(state);
  };
  const postLogin = (e) => {
    e.preventDefault();
    data = {
      email: state.email,
      password: state.password,
    };
    const URL = "http://localhost:3001/log";
    axios.post(URL, data).then((res) => {
      console.log(res.data);
      
      // if(res.data.email==)
      // {
      //   // navigate('/menu');
      // }
      // else
      // {

      // }
      
     
    });
  };

  return (
    <>
      <LoginNav />
      <div className="mt-4">
        <h2> Login </h2>
        <form onSubmit={postLogin}>
          <div className="form-group">
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              placeholder="Enter email"
              name="email"
              onChange={handleOnChange}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              className="form-control"
              id="exampleInputPassword1"
              placeholder="Password"
              name="password"
              onChange={handleOnChange}
            />
          </div>
         
            <button type="submit" value="login" className="btn btn-dark">
              Login
            </button>
         
        </form>
      </div>
    </>
  );
};

export default Loginform;
