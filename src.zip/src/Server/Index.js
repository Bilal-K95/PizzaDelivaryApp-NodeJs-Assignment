const mongoose = require("mongoose");
const express = require("express");
const app = express();
const PORT = 3001;
const cors = require("cors");
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// DB connection

const DB = "mongodb://localhost:27017/menu";
mongoose
  .connect(DB, {
    useNewUrlParser: true,
  })
  .then(() => {
    console.log("connection succes fully");
  })
  .catch((err) => {
    console.log("no connection");
  });

//model schemas
const menuSchema = require("./model/menuSchema");
const userSchema = require("./model/userSchema");


app.post("/log", (req, res) => {
 userSchema.find({email:req.body.email,password:req.body.password},(err,data)=>
 {
   if(err) throw err;
   res.send(data)
 })
});

app.post("/signup", (req, res) => {
  console.log(req.body);
  // res.send("hello from other side");

  let name = req.body.name;
  let email = req.body.email;
  let mobile = req.body.mobile;
  let address = req.body.address;
  //store data or append data in post.json
  let ins = new userSchema(req.body);
  ins.save((err) => {
    if (err) {
      res.json({ err: 1, msg: "Not Registered" });
    } else {
      res.json({ err: 0, msg: "Registered" });
      console.log(ins);
    }
  });
});

app.get("/menu", (req, res) => {
  menuSchema.find({}, (err, data) => {
    if (err) throw err;
    else {
      res.send(data);
      console.log(data);
    }
  });
});

app.listen(PORT, (err) => {
  if (err) throw err;
  console.log(`working on port ${PORT}`);
});
